# Script de Vendas - SS Marketing e Divulgação

**Público-alvo:** Lojas de materiais de construção, depósitos de pedras/mármore/granito, importados, marmorarias, vidraçarias, empresas de alvenaria.

**Objetivo:** Apresentar os planos de marketing digital da SS Marketing e fechar a venda, destacando a especialização no setor de construção.

---

## 1. Abordagem Inicial / Quebra-Gelo

**(Vendedor):** "Bom dia/tarde, [Nome do Prospect]! Meu nome é [Seu Nome] e sou da SS Marketing e Divulgação. Acredito que você esteja à frente da [Nome da Empresa do Prospect], correto?"

**(Vendedor):** "Entrei em contato porque nossa empresa é especializada em marketing digital para o setor de construção civil, e temos acompanhado o mercado de [mencionar o segmento específico do prospect, ex: marmorarias] com bastante interesse. Percebemos que muitas empresas como a sua estão buscando novas formas de se destacar online e atrair mais clientes. É algo que faz sentido para você?"

---

## 2. Identificação de Dores / Desafios

**(Vendedor):** "Entendo. Muitas empresas do seu ramo nos procuram com desafios como:
*   Dificuldade em atrair clientes qualificados pela internet.
*   Não saber como usar as redes sociais para gerar vendas.
*   Ter um site ou redes sociais, mas sem resultados concretos.
*   Concorrência acirrada e a necessidade de se diferenciar.
*   Falta de tempo ou conhecimento para gerenciar o marketing digital.

Você se identifica com algum desses pontos, ou há outros desafios que sua empresa enfrenta hoje no ambiente digital?"

---

## 3. Apresentação da Solução (SS Marketing)

**(Vendedor):** "Compreendo perfeitamente. É exatamente para resolver esses desafios que a SS Marketing existe. Há 3 anos, nos dedicamos exclusivamente a ajudar empresas do setor de construção a transformarem sua presença digital em resultados reais.

Nossa expertise nos permite criar estratégias que realmente falam a língua do seu público, seja ele um construtor, um arquiteto ou o cliente final que está reformando. Não fazemos marketing genérico; fazemos marketing que entende de [mencionar o segmento do prospect novamente, ex: pedras e revestimentos]."

---

## 4. Apresentação dos Planos (Conectar com as Dores)

**(Vendedor):** "Para atender às diferentes necessidades e estágios de cada negócio, desenvolvemos três planos de marketing completos. Qual deles se encaixa melhor no momento atual da [Nome da Empresa do Prospect]?"

### A. Plano Básico — R$397/mês

**(Vendedor):** "O **Plano Básico** é perfeito para quem está começando no digital ou precisa fortalecer sua presença inicial. Se você sente que precisa 'marcar território' nas redes sociais e começar a aparecer para seu público, este é o ideal.

Com ele, você terá:
*   **8 artes mensais (feed e stories):** Conteúdo profissional para manter suas redes ativas.
*   **2 reels simples por mês:** Vídeos curtos para engajar e mostrar seus produtos/serviços de forma dinâmica.
*   **1 impulsionamento (valor não incluso):** Para que suas publicações alcancem mais pessoas interessadas.
*   **Agendamento de postagens e análise de perfil/bio:** Cuidamos da parte operacional e otimizamos sua vitrine digital.

É o pontapé inicial para começar a gerar visibilidade e reconhecimento de marca."

### B. Plano Intermediário — R$497/mês

**(Vendedor):** "Se você já tem alguma presença online, mas busca mais constância, crescimento e quer ir além do básico, o **Plano Intermediário** é a escolha certa. Ele é o nosso plano mais popular, pois oferece um salto significativo em resultados.

Você terá:
*   **12 artes mensais:** Mais conteúdo para manter seu público engajado.
*   **4 reels com edição leve por mês:** Mais vídeos e com um toque profissional para capturar a atenção.
*   **1 vídeo institucional de até 1 min (com roteiro simples):** Uma ferramenta poderosa para apresentar sua empresa, seus diferenciais ou um produto específico.
*   **2 impulsionamentos (valor não incluso):** Dobramos o alcance para atrair ainda mais clientes.
*   **Análise mensal de resultados, agendamento e legendas inclusas:** Monitoramos o que funciona, otimizamos suas legendas e garantimos que tudo esteja no ar no momento certo.

Este plano é para quem quer acelerar o crescimento e ver resultados mais expressivos."

### C. Plano Premium — R$897/mês

**(Vendedor):** "Agora, se a [Nome da Empresa do Prospect] busca uma solução completa para dominar o mercado digital, se destacar da concorrência e se tornar uma referência no seu segmento, o **Plano Premium** é a sua melhor aposta. É a solução mais robusta para quem quer resultados máximos.

Inclui:
*   **16 artes mensais:** Presença digital constante e de alta qualidade.
*   **6 reels editados por mês:** Conteúdo em vídeo de alto impacto para engajar e converter.
*   **2 vídeos institucionais com roteiro e edição profissional:** Produções de alta qualidade para fortalecer sua marca e produtos.
*   **3 impulsionamentos (valor não incluso):** Máximo alcance para suas campanhas.
*   **Consultoria estratégica mensal:** Nosso diferencial! Teremos reuniões para alinhar estratégias, analisar o mercado e garantir que estamos sempre à frente.
*   **Agendamento, legendas e hashtags otimizadas:** Cuidamos de cada detalhe para o máximo desempenho.
*   **Criação de identidade visual básica (caso o cliente ainda não tenha):** Se sua marca precisa de um 'upgrade' visual, nós cuidamos disso.

Este plano é para quem quer uma parceria estratégica e resultados de alto nível."

---

## 5. Depoimentos / Prova Social

**(Vendedor):** "Para que você tenha ainda mais confiança, gostaria de compartilhar o que alguns de nossos clientes do setor de construção têm a dizer. Por exemplo, o Carlos Eduardo, do Depósito de Pedras Granito Real, disse que 'A SS Marketing transformou completamente nossa presença digital. Em 6 meses, nosso Instagram cresceu 300% e as vendas aumentaram significativamente. O pessoal entende muito do nosso setor!'

Temos diversos outros casos de sucesso com marmorarias, vidraçarias e lojas de materiais de construção que viram seus negócios decolarem com a nossa ajuda."

---

## 6. Lidando com Objeções Comuns

*   **"Está muito caro."**
    **(Vendedor):** "Entendo sua preocupação com o investimento, [Nome do Prospect]. No entanto, considere o retorno que um marketing digital estratégico pode trazer. Quantos novos clientes você precisaria atrair para que o investimento se pague e comece a gerar lucro? Nossos planos são pensados para serem um investimento, não um custo, gerando visibilidade e vendas que você não conseguiria de outra forma. Além disso, ao comparar com a contratação de um profissional interno ou uma agência generalista, nosso custo-benefício é muito superior, dada nossa especialização no seu nicho."

*   **"Não tenho tempo para isso."**
    **(Vendedor):** "Essa é uma preocupação comum, e é exatamente por isso que a SS Marketing cuida de tudo para você! Desde a criação das artes e vídeos até o agendamento e análise de resultados. Sua única preocupação será atender aos novos clientes que vamos atrair. Nosso objetivo é liberar seu tempo para focar no que você faz de melhor: gerenciar seu negócio de construção."

*   **"Já tentei marketing digital e não funcionou."**
    **(Vendedor):** "Compreendo sua frustração. Infelizmente, muitas empresas têm experiências ruins com marketing digital genérico. O nosso diferencial é a **especialização**. Conhecemos o seu público, os termos técnicos, os produtos e os desafios do setor de construção. Isso nos permite criar campanhas muito mais eficazes e direcionadas, que realmente geram resultados. Podemos analisar o que não funcionou antes e mostrar como nossa abordagem é diferente."

*   **"Preciso pensar/conversar com meu sócio."**
    **(Vendedor):** "Claro, [Nome do Prospect], é uma decisão importante. Para facilitar sua conversa com seu sócio, que informações adicionais seriam úteis? Posso enviar um resumo dos planos por e-mail ou até mesmo agendar uma breve reunião com vocês dois para tirar todas as dúvidas. Qual seria o melhor dia e horário para um breve alinhamento?"

---

## 7. Chamada para Ação / Fechamento

**(Vendedor):** "[Nome do Prospect], diante do que conversamos e dos resultados que podemos gerar para a [Nome da Empresa do Prospect], qual dos planos você acredita que é o ideal para começarmos a transformar sua presença digital e atrair mais clientes? Podemos iniciar com o [Plano Sugerido] e já colocar sua empresa em destaque no mercado."

**(Vendedor):** "Que tal agendarmos uma reunião rápida para formalizarmos o plano escolhido e darmos o primeiro passo rumo ao crescimento da [Nome da Empresa do Prospect] no digital? Posso te enviar a proposta detalhada por e-mail agora mesmo."

---

**Lembre-se:**
*   **Ouça mais, fale menos:** Entenda as dores do prospect.
*   **Personalize:** Use o nome da empresa e mencione o segmento específico.
*   **Foque nos benefícios:** Como o plano resolve a dor do cliente, não apenas nas características.
*   **Confiança:** Transmita segurança na sua especialização.
*   **Próximo passo:** Sempre direcione para uma próxima ação clara (reunião, envio de proposta, fechamento).

