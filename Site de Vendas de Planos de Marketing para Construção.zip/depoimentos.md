# Depoimentos de Clientes - SS Marketing e Divulgação

## Depoimento 1
**Nome:** Carlos Eduardo Silva
**Empresa:** Depósito de Pedras Granito Real
**Cargo:** Proprietário
**Avaliação:** ⭐⭐⭐⭐⭐
**Depoimento:** "A SS Marketing transformou completamente nossa presença digital. Em 6 meses, nosso Instagram cresceu 300% e as vendas aumentaram significativamente. O pessoal entende muito do nosso setor!"

## Depoimento 2
**Nome:** Marina Santos
**Empresa:** Marmoraria Bela Vista
**Cargo:** Gerente de Marketing
**Avaliação:** ⭐⭐⭐⭐⭐
**Depoimento:** "Trabalho incrível! As artes ficaram lindas e os vídeos institucionais nos ajudaram muito a mostrar a qualidade dos nossos serviços. Recomendo demais!"

## Depoimento 3
**Nome:** Roberto Oliveira
**Empresa:** Vidraçaria Cristal
**Cargo:** Sócio-Proprietário
**Avaliação:** ⭐⭐⭐⭐⭐
**Depoimento:** "Finalmente encontrei uma agência que entende o mercado de construção. Os resultados apareceram rapidinho e o atendimento é nota 10!"

## Depoimento 4
**Nome:** Ana Paula Costa
**Empresa:** Materiais de Construção Forte
**Cargo:** Diretora Comercial
**Avaliação:** ⭐⭐⭐⭐⭐
**Depoimento:** "A consultoria estratégica do plano premium foi fundamental para estruturarmos nossa estratégia digital. Hoje somos referência na região!"

## Depoimento 5
**Nome:** José Carlos Ferreira
**Empresa:** Alvenaria & Construções JCF
**Cargo:** Proprietário
**Avaliação:** ⭐⭐⭐⭐⭐
**Depoimento:** "Excelente trabalho! As postagens são sempre criativas e chamam atenção. Nosso WhatsApp não para de tocar com novos clientes!"

## Depoimento 6
**Nome:** Luciana Mendes
**Empresa:** Importadora de Revestimentos Premium
**Cargo:** Gerente Geral
**Avaliação:** ⭐⭐⭐⭐⭐
**Depoimento:** "A SS Marketing conseguiu traduzir perfeitamente a sofisticação dos nossos produtos importados nas redes sociais. Estamos muito satisfeitos!"

