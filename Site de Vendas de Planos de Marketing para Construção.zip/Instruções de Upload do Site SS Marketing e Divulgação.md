# Instruções de Upload do Site SS Marketing e Divulgação

Este guia detalha como fazer o upload dos arquivos do seu site para um servidor de hospedagem web. Você pode usar um cliente FTP (File Transfer Protocol) ou o gerenciador de arquivos do painel de controle da sua hospedagem.

## Opção 1: Usando um Cliente FTP (Recomendado para a maioria dos usuários)

Clientes FTP como FileZilla (gratuito e de código aberto) são as ferramentas mais comuns para transferir arquivos para o seu servidor.

### 1. Baixe e Instale um Cliente FTP

- **FileZilla (Windows, macOS, Linux):** [https://filezilla-project.org/](https://filezilla-project.org/)

### 2. Obtenha suas Credenciais FTP

Você precisará das seguintes informações, que são fornecidas pela sua empresa de hospedagem (geralmente no e-mail de boas-vindas ou no painel de controle da hospedagem):

- **Host FTP:** (Ex: `ftp.seusite.com.br` ou um endereço IP)
- **Nome de Usuário FTP:** (Ex: `usuario@seusite.com.br`)
- **Senha FTP:**
- **Porta FTP:** (Geralmente 21, mas pode variar)

### 3. Conecte-se ao seu Servidor FTP

Abra o FileZilla (ou seu cliente FTP preferido) e insira suas credenciais nos campos apropriados:

- **Host:** Insira o Host FTP.
- **Username:** Insira o Nome de Usuário FTP.
- **Password:** Insira a Senha FTP.
- **Port:** Insira a Porta FTP (se diferente de 21).

Clique em "Quickconnect" ou "Conectar".

### 4. Navegue até o Diretório Correto no Servidor

Após a conexão, você verá duas seções principais no seu cliente FTP:

- **Site Local:** Seus arquivos no seu computador.
- **Site Remoto:** Os arquivos no seu servidor de hospedagem.

No "Site Remoto", navegue até o diretório público do seu site. Os nomes comuns para este diretório são:

- `public_html`
- `www`
- `htdocs`
- O nome do seu domínio (Ex: `seusite.com.br`)

**É crucial fazer o upload dos arquivos para o diretório correto para que seu site seja visível na internet.**

### 5. Faça o Upload dos Arquivos do Site

No "Site Local", navegue até a pasta `ss_marketing_site` que contém os arquivos do seu site (index.html, pasta css, pasta js, pasta images).

Selecione todos os arquivos e pastas dentro de `ss_marketing_site` (index.html, css, js, images) e arraste-os do painel "Site Local" para o diretório público do seu "Site Remoto".

O cliente FTP começará a transferir os arquivos. O tempo de upload dependerá do tamanho dos arquivos e da sua conexão com a internet.

### 6. Verifique seu Site

Após a conclusão do upload, abra seu navegador e digite o endereço do seu domínio (Ex: `www.ssmarketing.com.br`). Seu site deve estar online!

## Opção 2: Usando o Gerenciador de Arquivos do Painel de Controle da Hospedagem

A maioria dos provedores de hospedagem oferece um gerenciador de arquivos baseado na web (como o cPanel File Manager) que permite fazer o upload de arquivos diretamente pelo navegador.

### 1. Acesse seu Painel de Controle

Faça login no painel de controle da sua hospedagem (Ex: cPanel, Plesk, etc.).

### 2. Encontre o Gerenciador de Arquivos

Procure por uma opção como "Gerenciador de Arquivos", "File Manager" ou similar.

### 3. Navegue até o Diretório Público

Dentro do gerenciador de arquivos, navegue até o diretório público do seu site (geralmente `public_html`, `www`, `htdocs`).

### 4. Faça o Upload dos Arquivos

Use a função de "Upload" (geralmente um botão ou ícone) para selecionar e enviar os arquivos do seu computador para o servidor. Você pode precisar compactar a pasta `ss_marketing_site` em um arquivo `.zip` e depois descompactá-la no servidor.

### 5. Verifique seu Site

Após o upload e descompactação (se aplicável), verifique seu site no navegador.

---

**Observação:** Se você encontrar problemas, consulte a documentação de suporte da sua empresa de hospedagem ou entre em contato com o suporte técnico deles. Eles poderão fornecer instruções específicas para o seu ambiente.

