# E-mail de Prospecção - SS Marketing e Divulgação

**Assunto:** Como [Nome da Empresa do Prospect] pode atrair mais clientes no setor de construção?

Prezado(a) [Nome do Prospect],

Meu nome é [Seu Nome] e sou da SS Marketing e Divulgação. Entro em contato porque nossa empresa é **especializada em marketing digital para o setor de construção civil**, com 3 anos de experiência ajudando negócios como o seu a crescerem online.

Sabemos que empresas de [mencionar o segmento específico do prospect, ex: marmorarias, materiais de construção] enfrentam desafios únicos para se destacar e atrair clientes qualificados na internet. Muitos se deparam com:

*   Dificuldade em transformar redes sociais em vendas.
*   Concorrência acirrada e a necessidade de diferenciação.
*   Falta de tempo para gerenciar o marketing digital de forma eficaz.

Nossa expertise nos permite criar estratégias que realmente falam a língua do seu público, gerando resultados concretos. Não fazemos marketing genérico; fazemos marketing que entende do seu negócio.

Gostaria de agendar uma breve conversa de 15 minutos para entender melhor suas necessidades e mostrar como a SS Marketing pode ajudar a [Nome da Empresa do Prospect] a atrair mais clientes e aumentar sua visibilidade online.

Qual seria o melhor dia e horário para você esta semana?

Atenciosamente,

[Seu Nome]
[Seu Cargo]
SS Marketing e Divulgação
(35) 99146-5282
www.ssmarketing.com.br (ou link do site após hospedagem)

---

**Pontos Chave Utilizados:**
*   **Especialização no setor de construção:** Abordagem direta sobre o nicho.
*   **Dores do cliente:** Listagem de desafios comuns para gerar identificação.
*   **Solução concisa:** Apresentação da SS Marketing como a solução especializada.
*   **Prova social implícita:** 3 anos de experiência e foco em resultados.
*   **Chamada para Ação (CTA) clara:** Convite para uma conversa breve e focada.
*   **Personalização:** Campos para [Nome do Prospect], [Nome da Empresa do Prospect] e [mencionar o segmento específico do prospect].

